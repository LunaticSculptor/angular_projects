export interface Weather {
    temperature: number;
    humidity: number;
    condition: string;
  }
  