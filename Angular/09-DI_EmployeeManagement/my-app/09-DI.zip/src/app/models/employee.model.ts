export interface EmployeeModel {
    id: number,
    name: string,
    department: string
}
