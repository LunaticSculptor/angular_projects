const emojiList = [
    { emoji: "😀", name: "Grinning Face" },
    { emoji: "😂", name: "Face with Tears of Joy" },
    { emoji: "❤️", name: "Red Heart" },
    { emoji: "🔥", name: "Fire" },
    { emoji: "👍", name: "Thumbs Up" },
    { emoji: "🚀", name: "Rocket" },
    { emoji: "🌟", name: "Glowing Star" },
    { emoji: "🎉", name: "Party Popper" },
    { emoji: "😊", name: "Smiling Face with Smiling Eyes" },
    { emoji: "🤔", name: "Thinking Face" },
];